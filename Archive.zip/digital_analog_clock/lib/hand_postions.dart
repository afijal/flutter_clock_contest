class HandPositions {
  //actually hour and minutes are of same length so it won't matter
  final double hour;
  final double minutes;

  HandPositions(this.hour, this.minutes);
}
